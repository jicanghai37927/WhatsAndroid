Java Prettify 1.2.1
========================================

This library is a java port of Google Prettify 
(http://google-code-prettify.googlecode.com). The copyright holder of the 
Prettify is mikesamuel@gmail.com. It is licensed under the Apache License 
Version 2.

This port is distributed under Apache license Version 2, you can find the 
license terms in the file 'LICENSE.txt'. You can find a sample of the license 
at http://www.opensource.org/licenses/Apache-2.0.

This library is currently hosted by Google Code at 
http://java-prettify.googlecode.com. You can find the examples, guide as well 
as source code and tests in this web page. An example is provided in 
/src/prettify/example/Example.java. This version contains all the languages 
supported and themes in Prettify (4 Mar 2013).


24 Apr 2012
