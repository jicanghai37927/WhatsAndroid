Java SyntaxHighlighter 1.2.0
========================================

This library is a java port of SyntaxHighlighter 
(http://alexgorbatchev.com/SyntaxHighlighter). The copyright holder of the 
SyntaxHighlighter is Alex Gorbatchev. It is dual licensed under the MIT and 
LGPL licenses.

This port is written by Chan Wai Shing (cws1989@gmail.com) distributed under 
the MIT and LGPL licenses, you can find the license terms in the file 
'LICENSE-MIT.txt' and 'LICENSE-LGPL.txt'. You can find a sample of the license 
at http://www.opensource.org/licenses/Apache-2.0 and 
http://www.opensource.org/licenses/lgpl-3.0.

This library is currently hosted by Google Code at 
http://java-syntax-highlighter.googlecode.com. You can find the examples, guide 
as well as source code and tests in this web page. An example is provided in 
/src/syntaxhighlighter/example/Example.java. This version contains all the 
brushes and themes in SyntaxHighlighter 3.0.83.


25 Jan 2012
