/**
 * All themes that comes with release.
 */
package syntaxhighlighter.theme;